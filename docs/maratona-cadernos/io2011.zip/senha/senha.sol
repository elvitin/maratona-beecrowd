Teste 1
2 5 6 7 8 9

Teste 2
2 5 6 7 8 9

Teste 3
2 5 6 7 8 9

Teste 4
3 8 4 7 2 9

Teste 5
3 8 4 7 2 9

Teste 6
2 2 2 2 2 2

Teste 7
2 4 2 4 2 4

Teste 8
4 4 4 4 4 4

Teste 9
4 2 4 2 4 2

Teste 10
1 2 3 4 5 6

