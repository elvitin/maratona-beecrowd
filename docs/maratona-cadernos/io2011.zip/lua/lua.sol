Teste 1
-6 13

Teste 2
55 120

Teste 3
-4 46

Teste 4
-38 -38

Teste 5
-5 18

Teste 6
-71 167

Teste 7
-48 59

Teste 8
-3 -3

Teste 9
-60 54

Teste 10
-137 182

Teste 11
17 75

Teste 12
13 13

Teste 13
-93 -51

Teste 14
53 53

Teste 15
60 88

Teste 16
163 163

Teste 17
-111 -59

Teste 18
-67 106

Teste 19
-163 172

Teste 20
-110 145

Teste 21
-94 135

Teste 22
-187 109

Teste 23
-35 115

Teste 24
-37 34

Teste 25
-1 55

Teste 26
-21 97

Teste 27
-158 177

Teste 28
-26 -26

Teste 29
141 141

Teste 30
115 115

Teste 31
18 91

Teste 32
-178 187

Teste 33
-82 -4

Teste 34
-5 -5

Teste 35
-47 -2

Teste 36
176 194

Teste 37
-175 108

Teste 38
-147 -17

Teste 39
-27 -16

Teste 40
-167 84

Teste 41
-20 -20

Teste 42
-95 86

Teste 43
-42 35

Teste 44
-94 21

Teste 45
-131 185

Teste 46
-110 -55

Teste 47
-37 -37

Teste 48
-44 -44

Teste 49
-127 -66

Teste 50
43 43

Teste 51
-54 -54

Teste 52
-8 84

Teste 53
-81 31

Teste 54
-34 24

Teste 55
-173 -173

Teste 56
99 99

Teste 57
46 46

Teste 58
24 24

Teste 59
-178 57

Teste 60
-52 29

Teste 61
198 198

Teste 62
-110 -110

Teste 63
1 40

Teste 64
55 87

Teste 65
173 173

Teste 66
-36 -36

Teste 67
-18 -18

Teste 68
-77 -31

Teste 69
1 73

Teste 70
-108 -108

Teste 71
-53 -21

Teste 72
-124 27

Teste 73
-19 -19

Teste 74
-74 20

Teste 75
-193 128

Teste 76
2 2

Teste 77
-157 109

Teste 78
-14 34

Teste 79
-43 -43

Teste 80
21 86

Teste 81
-5 70

Teste 82
-153 17

Teste 83
-91 -88

Teste 84
-151 162

Teste 85
-183 185

Teste 86
-74 53

Teste 87
-159 -159

Teste 88
-93 35

Teste 89
87 87

Teste 90
-32 36

Teste 91
8 54

Teste 92
-20 38

Teste 93
-67 -39

Teste 94
-3 83

Teste 95
-52 113

Teste 96
-95 126

Teste 97
38 42

Teste 98
-5 92

Teste 99
-34 8

Teste 100
22 22

