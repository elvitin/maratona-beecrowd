SET 1
Bo
Jean
Claude
Marybeth
William
Kevin
Pat
SET 2
Jim
Zoe
Frederick
Annabelle
Joey
Ben
SET 3
John
Fran
Cece
Stan
Bill
SET 4
Caio
Davi
Joao
Pedro
Arthur
Heitor
Rafael
Gabriel
Lorenzo
Nicolas
Henrique
GuilhermeAntoniodeSaSouza
Leonardo
Bernardo
Matheus
Gustavo
Pietro
Miguel
Felipe
Vitor
Lucas
Enzo
Caua
SET 5
Bo
Jean
Claude
Marybeth
William
Kevin
Pat
